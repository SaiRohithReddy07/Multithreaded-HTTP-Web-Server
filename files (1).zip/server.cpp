// Multithreaded HTTP web server
// Build: g++ -std=c++17 -O2 -pthread server.cpp -o server
// Run:   ./server [port] [num_threads] [document_root]

#include <arpa/inet.h>
#include <netinet/in.h>
#include <poll.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#include <atomic>
#include <cerrno>
#include <cstdint>
#include <condition_variable>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <mutex>
#include <queue>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

// ---------------------------------------------------------------------
// Globals
// ---------------------------------------------------------------------
static std::atomic<bool> g_running{true};

static void handleSignal(int) {
    g_running = false;
}

// ---------------------------------------------------------------------
// Logger: thread-safe, writes to console and a file
// ---------------------------------------------------------------------
class Logger {
public:
    explicit Logger(const std::string& filename) : file_(filename, std::ios::app) {}

    void log(const std::string& message) {
        std::lock_guard<std::mutex> lock(mutex_);
        std::string line = "[" + timestamp() + "] " + message;
        std::cout << line << std::endl;
        if (file_.is_open()) {
            file_ << line << std::endl;
        }
    }

private:
    static std::string timestamp() {
        std::time_t now = std::time(nullptr);
        std::tm tmBuf{};
        localtime_r(&now, &tmBuf);
        char buf[32];
        std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tmBuf);
        return buf;
    }

    std::mutex mutex_;
    std::ofstream file_;
};

// ---------------------------------------------------------------------
// ThreadPool: fixed workers pulling client sockets off a shared queue
// ---------------------------------------------------------------------
class ThreadPool {
public:
    using Task = std::function<void(int)>;

    ThreadPool(size_t numThreads, Task handler) : handler_(std::move(handler)) {
        for (size_t i = 0; i < numThreads; ++i) {
            workers_.emplace_back(&ThreadPool::workerLoop, this);
        }
    }

    ~ThreadPool() { shutdown(); }

    void submit(int clientFd) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            queue_.push(clientFd);
        }
        cv_.notify_one();
    }

    // Stops accepting new work, lets workers finish what is queued, then joins.
    void shutdown() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (stopping_) return;
            stopping_ = true;
        }
        cv_.notify_all();
        for (std::thread& t : workers_) {
            if (t.joinable()) t.join();
        }
    }

private:
    void workerLoop() {
        while (true) {
            int clientFd = -1;
            {
                std::unique_lock<std::mutex> lock(mutex_);
                cv_.wait(lock, [this] { return stopping_ || !queue_.empty(); });
                if (queue_.empty()) {
                    return;  // stopping and nothing left to do
                }
                clientFd = queue_.front();
                queue_.pop();
            }
            handler_(clientFd);
        }
    }

    std::vector<std::thread> workers_;
    std::queue<int> queue_;
    std::mutex mutex_;
    std::condition_variable cv_;
    bool stopping_ = false;
    Task handler_;
};

// ---------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------
struct HttpRequest {
    std::string method;
    std::string path;
    std::string version;
};

static std::string statusText(int code) {
    switch (code) {
        case 200: return "OK";
        case 400: return "Bad Request";
        case 403: return "Forbidden";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 500: return "Internal Server Error";
        default:  return "Unknown";
    }
}

static std::string mimeType(const std::string& path) {
    static const std::map<std::string, std::string> types = {
        {".html", "text/html"},       {".htm", "text/html"},
        {".css", "text/css"},         {".js", "application/javascript"},
        {".json", "application/json"},{".txt", "text/plain"},
        {".png", "image/png"},        {".jpg", "image/jpeg"},
        {".jpeg", "image/jpeg"},      {".gif", "image/gif"},
        {".svg", "image/svg+xml"},    {".ico", "image/x-icon"},
    };
    size_t dot = path.find_last_of('.');
    if (dot != std::string::npos) {
        auto it = types.find(path.substr(dot));
        if (it != types.end()) return it->second;
    }
    return "application/octet-stream";
}

static bool sendAll(int fd, const char* data, size_t length) {
    size_t sent = 0;
    while (sent < length) {
        ssize_t n = send(fd, data + sent, length - sent, MSG_NOSIGNAL);
        if (n <= 0) return false;
        sent += static_cast<size_t>(n);
    }
    return true;
}

static void sendResponse(int fd, int code, const std::string& contentType,
                         const std::string& body, bool includeBody = true) {
    std::ostringstream header;
    header << "HTTP/1.1 " << code << " " << statusText(code) << "\r\n"
           << "Content-Type: " << contentType << "\r\n"
           << "Content-Length: " << body.size() << "\r\n"
           << "Connection: close\r\n\r\n";
    std::string head = header.str();
    if (!sendAll(fd, head.data(), head.size())) return;
    if (includeBody && !body.empty()) {
        sendAll(fd, body.data(), body.size());
    }
}

static void sendError(int fd, int code) {
    std::string body = "<html><body><h1>" + std::to_string(code) + " " +
                       statusText(code) + "</h1></body></html>";
    sendResponse(fd, code, "text/html", body);
}

static bool parseRequestLine(const std::string& raw, HttpRequest& req) {
    size_t lineEnd = raw.find("\r\n");
    if (lineEnd == std::string::npos) return false;
    std::istringstream line(raw.substr(0, lineEnd));
    if (!(line >> req.method >> req.path >> req.version)) return false;
    return req.version.rfind("HTTP/", 0) == 0;
}

// Reads until the end of the headers, or fails on timeout / oversize.
static bool readRequest(int fd, std::string& out) {
    const size_t maxSize = 8192;
    char buffer[1024];
    while (out.find("\r\n\r\n") == std::string::npos) {
        ssize_t n = recv(fd, buffer, sizeof(buffer), 0);
        if (n <= 0) return false;
        out.append(buffer, static_cast<size_t>(n));
        if (out.size() > maxSize) return false;
    }
    return true;
}

// ---------------------------------------------------------------------
// WebServer
// ---------------------------------------------------------------------
class WebServer {
public:
    WebServer(int port, size_t threads, std::string docRoot)
        : port_(port),
          docRoot_(std::move(docRoot)),
          logger_("server.log"),
          pool_(threads, [this](int fd) { handleClient(fd); }) {}

    ~WebServer() {
        if (listenFd_ >= 0) close(listenFd_);
    }

    bool start() {
        listenFd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (listenFd_ < 0) {
            logger_.log(std::string("socket() failed: ") + std::strerror(errno));
            return false;
        }

        int opt = 1;
        setsockopt(listenFd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(static_cast<uint16_t>(port_));

        if (bind(listenFd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            logger_.log(std::string("bind() failed: ") + std::strerror(errno));
            return false;
        }
        if (listen(listenFd_, 128) < 0) {
            logger_.log(std::string("listen() failed: ") + std::strerror(errno));
            return false;
        }

        logger_.log("Server listening on port " + std::to_string(port_) +
                    ", serving files from '" + docRoot_ + "'");
        acceptLoop();
        return true;
    }

private:
    void acceptLoop() {
        pollfd pfd{listenFd_, POLLIN, 0};
        while (g_running) {
            // Poll with a timeout so we notice the shutdown flag promptly.
            int ready = poll(&pfd, 1, 500);
            if (ready <= 0) continue;

            sockaddr_in clientAddr{};
            socklen_t len = sizeof(clientAddr);
            int clientFd = accept(listenFd_, reinterpret_cast<sockaddr*>(&clientAddr), &len);
            if (clientFd < 0) continue;

            timeval timeout{5, 0};  // don't let slow clients hog a worker
            setsockopt(clientFd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

            pool_.submit(clientFd);
        }

        logger_.log("Shutdown requested, finishing pending requests...");
        close(listenFd_);
        listenFd_ = -1;
        pool_.shutdown();
        logger_.log("Server stopped cleanly.");
    }

    void handleClient(int fd) {
        std::string raw;
        HttpRequest req;

        if (!readRequest(fd, raw) || !parseRequestLine(raw, req)) {
            sendError(fd, 400);
            close(fd);
            return;
        }

        logger_.log(req.method + " " + req.path);

        if (req.method != "GET" && req.method != "HEAD") {
            sendError(fd, 405);
            close(fd);
            return;
        }

        serveFile(fd, req);
        close(fd);
    }

    void serveFile(int fd, const HttpRequest& req) {
        std::string path = req.path;
        size_t query = path.find('?');
        if (query != std::string::npos) path.erase(query);

        // Block directory traversal
        if (path.empty() || path[0] != '/' || path.find("..") != std::string::npos) {
            sendError(fd, 403);
            return;
        }
        if (path.back() == '/') path += "index.html";

        std::string fullPath = docRoot_ + path;

        struct stat st{};
        if (stat(fullPath.c_str(), &st) != 0 || !S_ISREG(st.st_mode)) {
            sendError(fd, 404);
            return;
        }

        std::ifstream file(fullPath, std::ios::binary);
        if (!file) {
            sendError(fd, 500);
            return;
        }

        std::ostringstream contents;
        contents << file.rdbuf();
        sendResponse(fd, 200, mimeType(fullPath), contents.str(), req.method == "GET");
    }

    int port_;
    std::string docRoot_;
    int listenFd_ = -1;
    Logger logger_;
    ThreadPool pool_;
};

// ---------------------------------------------------------------------
// main
// ---------------------------------------------------------------------
int main(int argc, char* argv[]) {
    int port = 8080;
    size_t threads = 4;
    std::string docRoot = "./public";

    try {
        if (argc > 1) port = std::stoi(argv[1]);
        if (argc > 2) threads = static_cast<size_t>(std::stoul(argv[2]));
    } catch (const std::exception&) {
        std::cerr << "Usage: " << argv[0] << " [port] [num_threads] [document_root]\n";
        return 1;
    }
    if (argc > 3) docRoot = argv[3];

    if (port < 1 || port > 65535 || threads == 0) {
        std::cerr << "Invalid port or thread count.\n";
        return 1;
    }

    struct sigaction sa{};
    sa.sa_handler = handleSignal;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, nullptr);
    sigaction(SIGTERM, &sa, nullptr);
    signal(SIGPIPE, SIG_IGN);

    WebServer server(port, threads, docRoot);
    return server.start() ? 0 : 1;
}
